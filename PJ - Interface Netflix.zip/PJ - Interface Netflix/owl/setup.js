$('.owl-carousel').owlCarousel({
    loop:true,/*Navegação infinita*/
    margin:10,/*espaço entre as figuras*/
    nav:true,/*movimen to de clicar e arrastar o mouse*/
        responsive:{/*adaptação para telas diferentes*/
        0:{
            items:1/*mostra apenas 1 imagem com tela próxima do 0px*/
        },
        600:{
            items:3/*mostra apenas 3 imagens com tela em do 600px*/
        },
        1000:{
            items:5/*mostra 5 imagens com tela em do 1000px*/
        }
    }
})